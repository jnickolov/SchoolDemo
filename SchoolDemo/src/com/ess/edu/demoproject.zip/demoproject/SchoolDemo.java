package com.ess.edu.demoproject;

import com.ess.edu.demoproject.ui.SchoolUIFactory;
import com.ess.edu.demoproject.util.Configurator;

import javafx.application.Application;
import javafx.scene.Scene;
import javafx.scene.layout.Pane;
import javafx.stage.Stage;

public class SchoolDemo extends  Application {

	@Override
	public void start (Stage stage) throws Exception {
		Pane root = SchoolUIFactory.createUI();
		
		Scene scn = new Scene (root);
		stage.setScene (scn);
		stage.setFullScreen (true);
		stage.show();
	}

	public static void main (String[] args) {
		try {
			Configurator.configureApplication();
			Application.launch (args);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}
