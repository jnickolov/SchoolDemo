package com.ess.edu.demoproject.ctrl;

import com.ess.edu.demoproject.ui.view.IObjectView;

public interface IControllerCommand <T> {
	public void execCommand (IObjectController<? extends T> ctrl, IObjectView<? extends T> view);
}
