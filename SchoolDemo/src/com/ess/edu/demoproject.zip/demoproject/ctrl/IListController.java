package com.ess.edu.demoproject.ctrl;

import java.util.Collection;

import com.ess.edu.demoproject.idname.IDName;

public interface IListController<T> {
	
	void elementSelected (int id);
	void editElement (int id);
	void elementAdded (IDName px);
	void elementRenamed (int id, String newName);
	void elementRemoved (int id);
	
	Collection<? extends IDName> createModel();
	IObjectController<T> getObjectController ();
	void setObjectController (IObjectController<T> oc);
	T getObjectById (int id);
}
