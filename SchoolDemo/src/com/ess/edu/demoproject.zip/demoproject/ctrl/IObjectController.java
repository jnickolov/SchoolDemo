package com.ess.edu.demoproject.ctrl;

import com.ess.edu.demoproject.ui.view.IObjectView;

public interface IObjectController <T> {
	public T getModel ();
	public void setModel (T model);
	void addView (IObjectView <T> view, boolean mustUpdate);
	void removeView (IObjectView <T> view);
	void updateViews ();
	void updateViews (IObjectView<T> srcView);

	void cmdReloadModel (IObjectView <T> view);
	void cmdUpdateModel (IObjectView <T> view);
	void cmdEditCanceled (IObjectView <T> view);
}
