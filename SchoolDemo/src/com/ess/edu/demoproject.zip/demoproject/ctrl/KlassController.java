package com.ess.edu.demoproject.ctrl;

import com.ess.edu.demoproject.entities.Klass;

public class KlassController extends ObjectController<Klass> {

}
