package com.ess.edu.demoproject.ctrl;

import java.util.Collection;
import java.util.LinkedList;

import com.ess.edu.demoproject.entities.Klass;
import com.ess.edu.demoproject.entities.School;
import com.ess.edu.demoproject.idname.IDName;
import com.ess.edu.demoproject.ui.view.IObjectView;
import com.ess.edu.demoproject.ui.view.editor.DialogEditorFX;
import com.ess.edu.demoproject.ui.view.impl.fx.KlassView;

import javafx.beans.property.IntegerProperty;
import javafx.beans.property.SimpleIntegerProperty;

public class KlassListController extends ListController <Klass> {
	private School school = null;
	private DialogEditorFX<Klass> editor = null;
	
	public KlassListController (School aSchool) {
		this.school = aSchool;
		this.setModel (this.createModel());
	}


	@Override
	public Collection <? extends IDName> createModel() {
		Collection <IDName> mdl = new LinkedList <IDName> ();
		
		if (this.school != null) {
			Collection <Klass> classes = this.school.getKlasses();
			for (Klass c: classes) {
				mdl.add (new IDName (c.getId(), c.getName()));
			}
		}
		return mdl;
	}

	@Override
	public Klass getObjectById (int id) {
		return this.school == null ? null : this.school.getKlassById (id);
	}

	@Override
	protected void createObjectMVC () {
		this.objCtrl = new KlassController() {
			@Override
			public void cmdUpdateModel (IObjectView<Klass> srcView) {
				this.updateModel (srcView);
				KlassListController.this.setModel (KlassListController.this.createModel());
				super.cmdUpdateModel (srcView);
			}
			
		};
		
		KlassView kv = new KlassView();
		objCtrl.addView (kv, false);
		this.editor = new DialogEditorFX<> ();
		editor.setView (kv);
		editor.setController(objCtrl);
	}

	@Override
	protected void doEditElement () {
		this.editor.show ();
	}
}
