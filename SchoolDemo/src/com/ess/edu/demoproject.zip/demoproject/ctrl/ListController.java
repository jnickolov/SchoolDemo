package com.ess.edu.demoproject.ctrl;

import java.util.Collection;

import com.ess.edu.demoproject.idname.IDName;

import javafx.beans.property.IntegerProperty;
import javafx.beans.property.SimpleIntegerProperty;

public abstract class ListController<T> extends ObjectController<Collection <? extends IDName>> implements IListController<T> {
	//private Collection <? extends IDName> model;
	protected IObjectController<T> objCtrl;
	private IntegerProperty selectedId = new SimpleIntegerProperty (0);
	
	public ListController () {
		//this.model = new LinkedList<>();
		this.objCtrl = null;
	}

	// Abstract methods
	@Override
	public abstract Collection<? extends IDName> createModel();

	@Override
	public abstract T getObjectById (int id);

	protected abstract void createObjectMVC ();

	// Commands
	@Override
	public void editElement (int id) {
		setObjectModel (id);
		doEditElement();
	}

	@Override
	public void elementSelected (int id) {
		this.selectedId.setValue (id);
	}

	@Override
	public void elementAdded (IDName px) {
		this.updateViews();
	}

	@Override
	public void elementRenamed (int id, String newName) {
		this.updateViews();
	}

	@Override
	public void elementRemoved (int id) {
		this.updateViews();
	}

	// Get / Set

	@Override
	public IObjectController<T> getObjectController () {
		return this.objCtrl;
	}
	
	@Override
	public void setObjectController (IObjectController<T> oc) {
		if (this.objCtrl == null) {
			createObjectMVC ();
		}
		this.objCtrl = oc;
	}

	
	protected void setObjectModel (int modelId) {
		if (this.objCtrl == null) {
			createObjectMVC ();
		}
		T objModel = this.getObjectById (modelId);
		this.objCtrl.setModel (objModel);
	}

	protected void doEditElement () {
		// override this
	}

	public final IntegerProperty selectedIdProperty() {
		return this.selectedId;
	}
	

	public final int getSelectedId() {
		return this.selectedIdProperty().get();
	}
	

	public final void setSelectedId(final int selectedID) {
		this.selectedIdProperty().set(selectedID);
	}
	
	
}
