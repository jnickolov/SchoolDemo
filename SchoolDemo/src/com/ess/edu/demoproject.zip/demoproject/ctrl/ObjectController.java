package com.ess.edu.demoproject.ctrl;

import java.util.Collection;
import java.util.LinkedList;

import com.ess.edu.demoproject.ui.view.IObjectView;

public class ObjectController<T> implements IObjectController<T> {
	private Collection <IObjectView <T>> views = null;
	private T model;
	
	public ObjectController() {
		this.views = new LinkedList<>();
	}

	@Override
	public void addView (IObjectView <T> view, boolean mustUpdate) {
		this.views.add (view);
		if (mustUpdate)
			view.displayModel (this.model);
	}

	@Override
	public void removeView (IObjectView <T> view) {
		this.views.remove (view);
	}

	@Override
	public T getModel () {
		return this.model;
	}

	@Override
	public void setModel (T obj) {
		this.model = obj;
		updateViews();
	}

	@Override
	public void cmdReloadModel (IObjectView<T> srcView) {
		this.updateViews ();
		System.out.println("Reload cmd");
	}

	@Override
	public void cmdUpdateModel (IObjectView<T> srcView) {
		this.updateModel (srcView);
		this.updateViews (srcView);
		System.out.println("Update cmd");
	}

	@Override
	public void cmdEditCanceled (IObjectView<T> srcView) {
		srcView.displayModel (this.model);
		System.out.println("Cancel cmd");
	}

	@Override
	public void updateViews () {
		for (IObjectView<T> view: this.views) {
			view.displayModel (model);
		}
	}

	@Override
	public void updateViews (IObjectView<T> srcView) {
		for (IObjectView<T> view: this.views) {
			if (view != srcView)
				view.displayModel (model);
		}
	}

	public void updateModel (IObjectView<T> srcView) {
		srcView.updateModel (model);  //no check if model == null
	}
}
