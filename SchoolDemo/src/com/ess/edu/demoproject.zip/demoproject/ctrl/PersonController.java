package com.ess.edu.demoproject.ctrl;

import com.ess.edu.demoproject.entities.Person;

public class PersonController extends ObjectController<Person> {
	// empty
}
