package com.ess.edu.demoproject.ctrl;

import com.ess.edu.demoproject.entities.Student;

public class StudentController extends ObjectController<Student> {

}
