package com.ess.edu.demoproject.ctrl;

import java.util.Collection;
import java.util.LinkedList;

import com.ess.edu.demoproject.entities.Klass;
import com.ess.edu.demoproject.entities.Student;
import com.ess.edu.demoproject.idname.IDName;
import com.ess.edu.demoproject.ui.view.IObjectView;
import com.ess.edu.demoproject.ui.view.editor.DialogEditorFX;
import com.ess.edu.demoproject.ui.view.impl.fx.StudentView;

public class StudentListController extends ListController<Student> {
	private Klass klass = null;
	private DialogEditorFX <Student> editor = null;

	public StudentListController () {
		this.klass = null;
	}
	
	public StudentListController (Klass c) {
		this();
		this.setKlass (c);
	}
	
	public void setKlass (Klass k) {
		this.klass = k;
		this.setModel (this.createModel());
	}
	
	@Override
	public Collection <? extends IDName> createModel() {
		Collection <IDName> mdl = new LinkedList <IDName> ();
		
		if (this.klass != null) {
			Collection <Student> students = this.klass.getStudents();
			for (Student c: students) {
				mdl.add (new IDName (c.getId(), c.getName()));
			}
		}
		return mdl;
	}

	@Override
	public Student getObjectById (int id) {
		return this.klass.getStudentbyId (id);
	}

	@Override
	protected void createObjectMVC() {
		this.objCtrl = new StudentController() {
			@Override
			public void cmdUpdateModel (IObjectView<Student> srcView) {
				this.updateModel (srcView);
				StudentListController.this.setModel (StudentListController.this.createModel());
				super.cmdUpdateModel (srcView);
			}
			
		};
		
		StudentView sv = new StudentView();
		objCtrl.addView (sv, false);
		this.editor = new DialogEditorFX<> ();
		editor.setView (sv);
		editor.setController(objCtrl);
		
	}

	@Override
	protected void doEditElement () {
		this.editor.show ();
	}


}
