package com.ess.edu.demoproject.ctrl;

import com.ess.edu.demoproject.entities.Subject;

public class SubjectController extends ObjectController <Subject> {
	//empty
}
