package com.ess.edu.demoproject.ctrl;

import com.ess.edu.demoproject.entities.Teacher;

public class TeacherController extends ObjectController <Teacher>{
	// empty
}
