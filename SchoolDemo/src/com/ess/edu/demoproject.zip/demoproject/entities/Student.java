package com.ess.edu.demoproject.entities;

import java.util.HashMap;
import java.util.Map;
import java.util.TreeMap;

import com.ess.edu.demoproject.util.Grade;
import com.ess.edu.demoproject.util.InvalidGradeException;

public class Student extends Person {
	
	private Map <String, Grade> grades = null;
	
	public Student (String firstName, String lastName) {
		super (firstName, lastName);
		this.grades = new HashMap<>();
	}

	public Student () {
		super ("", "");
	}

	public double getGrade (String subject) {
		Grade ans = this.grades.get (subject);
		return ans != null ? ans.getValue() : 0;
	}
	
	public void setGrade (String subject, double grade) throws InvalidGradeException {
		this.grades.put (subject, new Grade (grade));
	}

	public double getAverageGrade () {
		if (this.grades == null || this.grades.size() == 0)
			return 0.0;
		
		double sum = 0.0;
		for (String sbj: this.grades.keySet()) {
			sum += this.grades.get (sbj).getValue();  // no need to check 
		}
		
		return sum / this.grades.size();
	}
	
	public Map <String, Double> getGrades () {
		Map <String,Double> res = new TreeMap<String, Double>();
		if (grades != null) {
			for (String key: grades.keySet()) {
				res.put (key, grades.get (key).getValue());
			}
		}
		return res;
	}
	
	@Override
	public String toString() {
		String ps = super.toString();
		if (grades != null) {
			ps += "\nGrades: \n";
			for (String key: grades.keySet()) {
				ps += "    " + key + ": " + grades.get (key) + "\n";
			}
		} else {
			ps += "\nGrades: NONE\n";
		}
		
		return ps;
	}

}

