package com.ess.edu.demoproject.ui;

import com.ess.edu.demoproject.util.Configurator;

import javafx.scene.control.Label;
import javafx.scene.layout.Pane;
import javafx.scene.layout.StackPane;

public class SchoolUIFactory extends Pane {

	public static Pane createUI() {
		String uiLayout = Configurator.getInstance().getProperty (Configurator.LAYOUT_KEY);
		if (Configurator.LAYOUT_FLAT.equals (uiLayout)) {
			return createFlatLayot();
		} else if (Configurator.LAYOUT_TABS.equals (uiLayout)) {
			return createTabedLayot();
		} else {
			return new StackPane (new Label ("Unsupported layout"));
		}
	}

	private static Pane createTabedLayot() {
		// TODO Auto-generated method stub
		return null;
	}

	private static Pane createFlatLayot() {
		// TODO Auto-generated method stub
		return null;
	}
	
	
}
