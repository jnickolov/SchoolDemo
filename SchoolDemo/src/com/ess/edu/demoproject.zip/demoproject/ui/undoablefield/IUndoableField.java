package com.ess.edu.demoproject.ui.undoablefield;

public interface IUndoableField {
	public void undoValue ();
}
