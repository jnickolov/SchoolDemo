package com.ess.edu.demoproject.ui.undoablefield.text;

public class DoubleUndoableField extends UndoableTextField <Double> {

	public DoubleUndoableField() {
		super();
	}

	public DoubleUndoableField (Double initValue) {
		super (initValue);
	}

}
