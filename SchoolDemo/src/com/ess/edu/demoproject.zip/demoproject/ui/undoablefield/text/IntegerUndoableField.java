package com.ess.edu.demoproject.ui.undoablefield.text;

public class IntegerUndoableField extends UndoableTextField<Integer> {
	public IntegerUndoableField() {
		super();
	}

	public IntegerUndoableField(Integer initValue) {
		super (initValue);
	}
}
