package com.ess.edu.demoproject.ui.undoablefield.text;

public class StringUndoableField extends UndoableTextField <String> {

	public StringUndoableField () {
		super();
	}

	public StringUndoableField (String initValue) {
		super (initValue);
	}

}
