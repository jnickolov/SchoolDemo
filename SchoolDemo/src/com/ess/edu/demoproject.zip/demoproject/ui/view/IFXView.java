package com.ess.edu.demoproject.ui.view;

import javafx.scene.Node;

public interface IFXView {
	Node getNode();  // JavaFX specific
}
