package com.ess.edu.demoproject.ui.view;

import java.util.Collection;

import com.ess.edu.demoproject.ctrl.IListController;
import com.ess.edu.demoproject.idname.IDName;

public interface IListView<T> extends IObjectView <Collection<? extends IDName>> {
	void setController (IListController<? extends T> c);
}
