package com.ess.edu.demoproject.ui.view;

public interface IListViewFX<T> extends IListView<T>, IFXView {

}
