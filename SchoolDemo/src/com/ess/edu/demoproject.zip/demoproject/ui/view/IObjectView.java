package com.ess.edu.demoproject.ui.view;

import javafx.scene.Node;

public interface IObjectView <T> {
	void displayModel (T obj);
	void updateModel (T model);
}
