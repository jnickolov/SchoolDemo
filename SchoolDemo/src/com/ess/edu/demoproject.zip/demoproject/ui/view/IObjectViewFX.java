package com.ess.edu.demoproject.ui.view;

import javafx.scene.Node;

public interface IObjectViewFX<T> extends IObjectView<T>, IFXView {
}
