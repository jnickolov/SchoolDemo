package com.ess.edu.demoproject.ui.view;

public abstract class ObjectView<T> implements IObjectViewFX<T> {

	public ObjectView() {
		super();
	}

	@Override
	public abstract void displayModel(T model);

	@Override
	public abstract void updateModel(T model);

}