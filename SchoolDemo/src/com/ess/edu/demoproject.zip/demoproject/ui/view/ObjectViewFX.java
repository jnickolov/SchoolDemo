package com.ess.edu.demoproject.ui.view;

import javafx.scene.Node;

public abstract class ObjectViewFX<T> extends ObjectView<T> implements IFXView {
	protected Node node = null;
	
	@Override
	public Node getNode() {
		return this.node;
	}

}
