package com.ess.edu.demoproject.ui.view.editor;


import com.ess.edu.demoproject.ctrl.IObjectController;
import com.ess.edu.demoproject.ui.view.IObjectViewFX;

import javafx.event.EventHandler;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Separator;
import javafx.scene.input.KeyCode;
import javafx.scene.input.KeyEvent;
import javafx.scene.layout.*;
import javafx.stage.Modality;
import javafx.stage.Stage;

public class DialogEditorFX<T> extends Stage {
	private IObjectViewFX<T> view = null;
	private IObjectController<T> ctrl;
	private Pane viewHolder = null;
	private VBox pane;
	private Button btnSave = null, btnUpdate = null, btnCancel = null, btnReload = null;
	

	public DialogEditorFX () {
		this.initModality (Modality.APPLICATION_MODAL);
		
		this.initScene();
	}

	public void setView (IObjectViewFX<T> view) {
		this.view = view;
		addViewNode();
	}
	
	public void setController (IObjectController<T> ctrl) {
		this.ctrl = ctrl;
		if (this.ctrl != null) {
			this.viewHolder.addEventFilter(KeyEvent.KEY_RELEASED, new EventHandler<KeyEvent>(){
				@Override
				public void handle (KeyEvent e) {  // handle Ctrl-U for Undo
					if (e.getCode() == KeyCode.U && e.isControlDown()) {
						ctrl.cmdReloadModel (view);
						e.consume();
					}
				}
				
			});
			this.btnUpdate.setOnAction(e -> { this.ctrl.cmdUpdateModel (this.view); });
			this.btnSave.setOnAction(e -> { this.ctrl.cmdUpdateModel (this.view); this.close(); });
			this.btnReload.setOnAction(e -> { this.ctrl.cmdReloadModel (this.view); });
			this.btnCancel.setOnAction(e -> { this.ctrl.cmdEditCanceled (this.view); this.close(); });
		}
	}
	
	public IObjectViewFX getView () {
		return this.view;
	}
	
	public IObjectController getController () {
		return this.ctrl;
	}
	
	public void edit (T model) {
		if (this.ctrl != null) {
			this.ctrl.setModel (model);
		}
		this.show();
	}

	private void initScene () {
		this.viewHolder = new Pane();
		this.btnSave = new Button ("Save");
		this.btnUpdate = new Button ("Update");
		this.btnReload = new Button ("Reload");
		this.btnCancel = new Button ("Cancel");
		
		pane = new VBox (8.0);
		HBox cmdLine = new HBox (4.0);
		Separator sep = new Separator();
		sep.setMaxWidth(Double.MAX_VALUE);
		sep.setVisible (false);
		HBox.setHgrow (sep, Priority.ALWAYS);
		cmdLine.getChildren().addAll (this.btnReload, sep, this.btnUpdate, this.btnSave, this.btnCancel);
		cmdLine.setAlignment (Pos.CENTER_RIGHT);
		
		pane.setPadding (new Insets (8, 12, 8, 12));
		pane.getChildren().addAll (this.viewHolder, cmdLine);
		this.setScene (new Scene (pane));
	}
	
	private void addViewNode() {
		this.viewHolder.getChildren().clear();
		this.viewHolder.getChildren().add (this.getView().getNode());
	}
	
}
