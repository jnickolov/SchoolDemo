package com.ess.edu.demoproject.ui.view.impl.fx;

import java.util.Collection;

import com.ess.edu.demoproject.ctrl.IListController;
import com.ess.edu.demoproject.idname.IDName;
import com.ess.edu.demoproject.ui.view.IFXView;
import com.ess.edu.demoproject.ui.view.IListView;

import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.EventHandler;
import javafx.scene.Node;
import javafx.scene.control.ListView;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.Pane;

public class IDNameListView<T> implements IListView<T>, IFXView {
	private Pane pane;
	private ListView<IDName> listView;
	private IListController<? extends IDName> ctrl;
	
	public IDNameListView (IListController<? extends T> c) {
		this();
		this.setController (c);
	}
	
	public IDNameListView () {
		this.pane = new Pane();
		this.listView = new ListView<>();
		
		this.listView.getSelectionModel().selectedItemProperty().addListener (
            new ChangeListener<IDName>() {
                public void changed (ObservableValue<? extends IDName> ov, IDName oldVal, IDName newVal) {
                	try {
                		ctrl.elementSelected (newVal != null ? newVal.getID() : 0);
                	} catch (Exception e) {
                		// no element selected
                	}
            }
        });
		
		this.listView.addEventHandler(MouseEvent.MOUSE_CLICKED, new EventHandler<MouseEvent>(){

			@Override
			public void handle (MouseEvent evt) {
				if (evt.getClickCount() > 1) {
					int id = listView.getSelectionModel().selectedItemProperty().get().getID();
					System.out.println("Double click at: " + listView.getSelectionModel().selectedItemProperty().get().getName());
					ctrl.editElement (id);
				}
			}
			
		});

		this.pane.getChildren().add (this.listView);
		this.ctrl = null;
	}
	
	@Override
	public void displayModel (Collection <? extends IDName> mdl) {
		ObservableList<IDName> items = FXCollections.observableArrayList ();
		for (IDName idnm: mdl) {
			items.add (idnm);
		}
		
		this.listView.setItems (items);
	}

	@Override
	public void updateModel (Collection <? extends IDName> model) {
		// empty: this view cannot change the model
	}

	@Override
	public Node getNode() {
		// TODO Auto-generated method stub
		return pane;
	}

	@Override
	public void setController (IListController c) {
		this.ctrl = c;
		
	}
}
