package com.ess.edu.demoproject.ui.view.impl.fx;

import java.util.Map;

import com.ess.edu.demoproject.entities.Student;
import com.ess.edu.demoproject.ui.view.ObjectViewFX;
import com.ess.edu.demoproject.util.InvalidGradeException;

import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextArea;
import javafx.scene.layout.GridPane;

public class StudentView extends ObjectViewFX <Student> {
	private PersonView pv = null;
	private GridPane pane = null;
	private Map<String, Double> grades = null;
	
	protected String sGrades = "";
	protected Label  lblGrades = null;
	protected TextArea  taGrades = null;
	
	public StudentView () {
		this.pv = new PersonView();  // will call initUI
		//this.pane = this.pv.pane;
		this.initUI();
	}

	protected void initUI() {
		//this.pv.initUI();
		this.node = this.pv.getNode();
		this.pane = pv.pane;
		
		this.lblGrades = new Label ("Grades");
		this.pane.
		add (
				this.lblGrades, 0, 3);
		Button b = new Button ("Edit");
		b.setOnAction (e -> {  });
		this.pane.add(b, 1, 3);
		this.taGrades = new TextArea ("");
		this.pane.add (this.taGrades, 0, 4, 2, 1);
	}


	@Override
	public void displayModel (Student model) {
		this.pv.displayModel (model);
		
		this.grades = model.getGrades();
		this.sGrades = "";
		for (String s: grades.keySet()) {
			this.sGrades += s + ": " + grades.get (s) + "\n";
		}
		this.taGrades.setText (sGrades);
		
	}

	@Override
	public void updateModel (Student model) {
		this.pv.updateModel (model);
		for (String s: grades.keySet()) {
			try {
				model.setGrade (s, grades.get(s));
			} catch (InvalidGradeException e) {
				e.printStackTrace();
			}
		}
	}
}
