package com.ess.edu.demoproject.util;

public class InvalidGradeException extends Exception {
	private static final long serialVersionUID = -8806172230180527693L;

	public InvalidGradeException (String msg) {
		super (msg);
	}
}
