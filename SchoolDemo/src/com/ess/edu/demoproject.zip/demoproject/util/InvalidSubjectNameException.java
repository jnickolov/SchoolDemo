package com.ess.edu.demoproject.util;

public class InvalidSubjectNameException extends Exception {
	public InvalidSubjectNameException (String msg) {
		super (msg);
	}
}
